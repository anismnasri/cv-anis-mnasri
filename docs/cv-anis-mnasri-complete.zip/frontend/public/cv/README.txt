INSTRUCTIONS POUR AJOUTER VOS CV PDF
======================================

Pour que le téléchargement du CV fonctionne correctement, veuillez placer vos fichiers PDF dans ce dossier :

1. CV_Anis_MNASRI_FR.pdf - Version française de votre CV
2. CV_Anis_MNASRI_EN.pdf - Version anglaise de votre CV

Le site téléchargera automatiquement la bonne version selon la langue sélectionnée par l'utilisateur.

Vous pouvez utiliser les fichiers .docx que vous avez fournis et les convertir en PDF, ou créer de nouveaux PDF formatés.

Emplacement actuel : /app/frontend/public/cv/

Une fois les fichiers ajoutés, le bouton "Télécharger CV" / "Download CV" fonctionnera automatiquement.
